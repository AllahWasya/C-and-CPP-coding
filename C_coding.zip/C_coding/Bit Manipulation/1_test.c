#include<stdio.h>
int main()
{
    int x=11;
    x=x<<2;
    printf("value of x is: %d\n",x); // left shift is multiply by 2.
    x=x>>2;
    printf("Vale of right shift is : %d\n",x); // divide by 2;
}