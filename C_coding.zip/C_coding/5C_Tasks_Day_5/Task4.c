/*
Author : Allah Wasaya
Company : AQL Tech Solutions
1. In this program, It take name and age as input from the user.
2. The a pointer to character array is initialized having size of age.
3. age times names are stored in that array and then displayed. 
*/
/////////////////////////////// START ///////////////////////////////////////
// #include <stdio.h>
// #include<string.h>
// int main()
// {
//     char name[20];
//     int age;
//     printf("Enter your name: ");
//     scanf("%s",name);
//     printf("Enter your age :");
//     scanf("%d",&age);
//     printf("My name is %s and my age is %d",name,age);
//     char arr[age*strlen(name)];
//     printf("%ld",strlen(name));

//     char *ptr;
//     ptr=name;
//     for (int i = strlen(name); i < (age*strlen(name)+strlen(name)); i++)
//     {
       
//             arr[i]=*(ptr+(i/strlen(name)));
//             //*(ptr+(i/(strlen(name))))=name[i];
//             // printf("%c",);
//             printf("%c",arr[i]);
        
//     }
    
//     // // arr[0]=name[2];
 




/////////////////////////////  END ///////////////////////////////////////
