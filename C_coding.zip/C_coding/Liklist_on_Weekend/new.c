 // for (int i = 0; i < n; i++)
   // {
   //    for (int j = i+1; i < n; i++)
   //    {
   //       if (array[i]>array[j])
   //       {
   //          int temp;
   //          temp=array[i];
   //          array[i]=array[j];
   //          array[j]=temp;
   //       }
         
   //    }
      
   // }