// #include<stdio.h>
// void add_node(struct node *head, int data)
// {  
//     struct node *ptr, *temp;
//     ptr =head;
//     temp=(struct node*) malloc(sizeof(struct node));
//     temp->data=data;
//     temp->link=NULL;

//     while (/* condition */)
//     {
//         /* code */
//     }
    
// }


// int main()
// {
//     struct node
//     {
//         int data;
//         int *link;
//     };
// struct node *head =NULL;
// struct node *first =NULL;

// head =(struct node*)(malloc(sizeof(struct node)));
// first =(struct node*)(malloc(sizeof(struct node)));

// head->data=6;
// head->link=first;

// first->data=7;
// first->link=NULL;

// }
