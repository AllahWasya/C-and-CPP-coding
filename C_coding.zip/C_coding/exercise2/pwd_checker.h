#ifndef PWD_CHECKER_H
#define PWD_CHECKER_H

#include <stdbool.h>

bool check_password(const char *first_name, const char *last_name, const char *password);

#endif // PWD_CHECKER_H
