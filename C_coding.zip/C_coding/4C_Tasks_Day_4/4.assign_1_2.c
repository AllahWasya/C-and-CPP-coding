#include<stdio.h>
int main()
{
    char* str [] ="I  live in islamabad";
    char *str1;
   // str1=str;
    printf("%p", str );
    printf("\n");
    printf("%p", str1 );
    // int x[4]={47,49,73,81};
    // int y[4]={48,64,77,36};
    // int *ptr1;
    // ptr1 =x;
    // printf("%d\n",ptr1[3]);
    // int *ptr2;
    // ptr1=x;
    // ptr2=ptr1;
    // printf("%p\n%p\n",ptr1,ptr2);
    // printf("%d\n",*ptr1++);
    // printf("%d\n",*(x));
}