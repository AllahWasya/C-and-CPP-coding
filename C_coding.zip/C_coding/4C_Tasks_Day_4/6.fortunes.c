#include <stdio.h>
int main()
{
char *fortunes [] = {

    "I live in islamabd",
    "Islamabad is capital of pakisan",
    "Living here is great experience"
};
printf("%s\n",fortunes[0]);
}