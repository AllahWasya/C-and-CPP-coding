#include<stdio.h>
struct ListNode
{
float value;
struct ListNode *next;
};
