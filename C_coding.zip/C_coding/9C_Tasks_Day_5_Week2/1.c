// #include<stdio.h>
// int main()
// {
//     int a=6;
//     int *ptr=&a;
//     int *(&ptr1)=&ptr;
//     printf("%p\n",ptr1);
// }